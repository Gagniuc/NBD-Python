\
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output" / "export_excel"
OUT.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(DATA / "export_sql.csv")

marime = 1000

for i in range(0, len(df), marime):
    bucata = df.iloc[i:i+marime]
    nume_fisier = OUT / f"export_partea_{i//marime + 1}.xlsx"
    bucata.to_excel(nume_fisier, index=False)

print("Export finalizat:", OUT)

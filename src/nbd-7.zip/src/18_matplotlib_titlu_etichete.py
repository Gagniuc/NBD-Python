"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [10, 14, 13, 18, 20]

plt.plot(x, y)
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Grafic liniar")
plt.show()

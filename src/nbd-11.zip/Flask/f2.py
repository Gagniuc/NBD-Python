from flask import Flask

app = Flask(__name__)

@app.route("/salut/<nume>/<prenume>/<varsta>")
def salut(nume, prenume, varsta):
    return "Salut, " + nume + " " + prenume + ", ai " + varsta + " ani."

app.run(debug=True)


import sys
import tkinter as tk

titlu = "FEREASTRA"
culoare = "red"
numar = "0"
student = "necunoscut"

if len(sys.argv) > 1: titlu = sys.argv[1]
if len(sys.argv) > 2: culoare = sys.argv[2]
if len(sys.argv) > 3: numar = sys.argv[3]
if len(sys.argv) > 4: student = sys.argv[4]

secunde_ramase = 10

def actualizeaza_timer():
    global secunde_ramase
    eticheta_timer.config(text="Se inchide in " + str(secunde_ramase) + " secunde")

    if secunde_ramase == 0:
        fereastra.destroy()
        return

    secunde_ramase = secunde_ramase - 1
    fereastra.after(1000, actualizeaza_timer)

fereastra = tk.Tk()
fereastra.title(titlu)
fereastra.geometry("700x400")
fereastra.configure(bg=culoare)
fereastra.attributes("-topmost", True)
fereastra.lift()
fereastra.focus_force()

eticheta_text = tk.Label(fereastra, text="FEREASTRA " + numar, font=("Arial", 32), bg=culoare, fg="white")
eticheta_text.pack(pady=10)

eticheta_student = tk.Label(fereastra, text="STUDENT: " + student, font=("Arial", 24), bg=culoare, fg="yellow")
eticheta_student.pack(pady=5)

eticheta_timer = tk.Label(fereastra, text="", font=("Arial", 18), bg=culoare, fg="white")
eticheta_timer.pack(pady=5)

actualizeaza_timer()

fereastra.mainloop()
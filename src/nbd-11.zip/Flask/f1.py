from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "Server Flask pornit (I)"

@app.route("/x")
def x():
    return "Server Flask pornit (II)"

app.run(debug=True)


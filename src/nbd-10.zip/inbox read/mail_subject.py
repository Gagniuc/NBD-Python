import imaplib
import email
from email.header import decode_header

gmail = "gagniucp@gmail.com"
parola = "otjx fwgg djnn waot"

server = imaplib.IMAP4_SSL("imap.gmail.com")
server.login(gmail, parola)
server.select("INBOX")

status, mesaje = server.search(None, "ALL")
iduri = mesaje[0].split()

ultimele = iduri[-5:]

for id_email in ultimele:
    status, date = server.fetch(id_email, "(RFC822)")
    mesaj = email.message_from_bytes(date[0][1])

    subiect = mesaj["Subject"]
    if subiect:
        subiect = decode_header(subiect)[0][0]
        if isinstance(subiect, bytes):
            subiect = subiect.decode("utf-8", errors="ignore")

    expeditor = mesaj["From"]

    print("De la:", expeditor)
    print("Subiect:", subiect)
    print("-" * 40)

server.logout()
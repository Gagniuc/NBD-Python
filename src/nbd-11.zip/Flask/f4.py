from flask import Flask, request

app = Flask(__name__)

@app.route("/aduna")
def aduna():
    a = int(request.args.get("a"))
    b = int(request.args.get("b"))
    return str(a + b)

app.run(debug=True)


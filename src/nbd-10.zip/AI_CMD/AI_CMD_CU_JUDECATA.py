import requests
import json
import subprocess

text_client = input("Ce vrei sa afli? ")

prompt = """
Raspunde numai cu JSON.

{
  "comanda":""
}

Comenzi permise:
hostname
ipconfig
getmac
tasklist

Cerere:
""" + text_client

r = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "llama3.2",
        "prompt": prompt,
        "format": "json",
        "stream": False
    }
)

date = json.loads(r.json()["response"])

comanda = date["comanda"]

rezultat = subprocess.check_output(
    comanda,
    shell=True,
    text=True,
    encoding="utf-8",
    errors="ignore"
)

prompt_interpretare = """
Utilizatorul a intrebat:

""" + text_client + """

Rezultatul comenzii este:

""" + rezultat + """

Raspunde scurt si direct la intrebare.
Nu explica ce ai facut.
"""

r2 = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "llama3.2",
        "prompt": prompt_interpretare,
        "stream": False
    }
)

raspuns_final = r2.json()["response"]

print("\nRaspuns AI:\n")
print(raspuns_final)
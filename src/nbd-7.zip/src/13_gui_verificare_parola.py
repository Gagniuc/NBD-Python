"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk

def verifica():
    if entry.get() == "1234":
        label.config(text="Corect")
    else:
        label.config(text="Gresit")

root = tk.Tk()
root.geometry("300x200")
root.title("Verificare parola")

entry = tk.Entry(root, show="*")
entry.place(x=80, y=40, width=140)

btn = tk.Button(root, text="Check", command=verifica)
btn.place(x=100, y=80, width=100, height=30)

label = tk.Label(root, text="")
label.place(x=100, y=130, width=100)

root.mainloop()

import smtplib

gmail = "gagniucp@gmail.com"
parola = "otjx fwgg djnn waot"

server = smtplib.SMTP_SSL("smtp.gmail.com", 465)

server.login(gmail, parola)

server.sendmail(
    gmail,
    "gagniucp@gmail.com",
    "Subject: Test Python\n\nSalut din Python!"
)

server.quit()

print("Email trimis")
"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

fisier = DATA_DIR / "text.txt"

with open(fisier, "r", encoding="utf-8") as f:
    text = f.read()

print("Caractere 10-20:")
print(text[10:20])

print("De la caracterul 5 pana la final:")
print(text[5:])

print("Ultimele 10 caractere:")
print(text[-10:])

print("Primele 50 caractere:")
print(text[:50])

"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk

def afiseaza():
    text = entry.get()
    label.config(text="Ai scris: " + text)

root = tk.Tk()
root.title("Exemplu GUI")
root.geometry("400x250")

entry = tk.Entry(root)
entry.place(x=100, y=40, width=200, height=30)

button = tk.Button(root, text="Apasa", command=afiseaza)
button.place(x=150, y=90, width=100, height=40)

label = tk.Label(root, text="")
label.place(x=100, y=150, width=200, height=30)

root.mainloop()

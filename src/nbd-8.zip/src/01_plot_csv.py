\
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA = Path(__file__).resolve().parents[1] / "date_input"
fisier = DATA / "vanzari.csv"

df = pd.read_csv(fisier)

plt.plot(df["luna"], df["vanzari"], marker="o")
plt.xlabel("Luna")
plt.ylabel("Vanzari")
plt.title("Vanzari din CSV")
plt.show()

"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk

def afiseaza():
    text = entry.get()
    label.config(text="Ai scris: " + text)

root = tk.Tk()
root.title("Exemplu GUI")
root.geometry("300x150")

entry = tk.Entry(root)
entry.pack(pady=10)

button = tk.Button(root, text="Apasa", command=afiseaza)
button.pack()

label = tk.Label(root, text="")
label.pack(pady=10)

root.mainloop()

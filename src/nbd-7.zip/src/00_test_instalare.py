"""
Test rapid pentru mediul local.
"""
import sys

print("Python:", sys.version)

try:
    import pandas as pd
    print("pandas:", pd.__version__)
except ImportError:
    print("pandas nu este instalat. Ruleaza: pip install pandas")

try:
    import matplotlib
    print("matplotlib:", matplotlib.__version__)
except ImportError:
    print("matplotlib nu este instalat. Ruleaza: pip install matplotlib")

try:
    import tkinter
    print("tkinter: OK")
except ImportError:
    print("tkinter nu este disponibil.")

import pytesseract
from PIL import Image, ImageEnhance

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

cale = r"C:\Users\Paul\Desktop\factura.png"

img = Image.open(cale)
img = img.convert("L")
img = img.resize((img.width * 3, img.height * 3))
img = ImageEnhance.Contrast(img).enhance(2)

text = pytesseract.image_to_string(img, lang="ron+eng")

print(text)
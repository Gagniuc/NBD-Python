\
import tkinter as tk

secunde = 10

def update_timer():
    global secunde

    label.config(text=str(secunde))

    if secunde > 0:
        secunde -= 1
        root.after(1000, update_timer)
    else:
        label.config(text="Gata!")

root = tk.Tk()
root.title("Count down")
root.geometry("250x150")

label = tk.Label(root, text="", font=("Arial", 40))
label.pack(expand=True)

update_timer()

root.mainloop()

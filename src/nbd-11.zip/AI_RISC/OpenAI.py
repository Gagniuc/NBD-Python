from openai import OpenAI

client = OpenAI(
    api_key="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"
)

raspuns = client.responses.create(
    model="gpt-5.5",
    input="Salut!"
)

print(raspuns.output_text)
"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import pandas as pd

fisier = DATA_DIR / "date_mari.csv"
total = 0
numar_randuri = 0

for bucata in pd.read_csv(fisier, chunksize=1000):
    total += bucata["valoare"].sum()
    numar_randuri += len(bucata)

print("Randuri procesate:", numar_randuri)
print("Total:", total)

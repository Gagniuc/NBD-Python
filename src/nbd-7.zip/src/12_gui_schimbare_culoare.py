"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk

def rosu():
    root.config(bg="red")

def verde():
    root.config(bg="green")

root = tk.Tk()
root.geometry("300x200")
root.title("Schimbare culoare fundal")

b1 = tk.Button(root, text="Rosu", command=rosu)
b1.place(x=50, y=80, width=80, height=40)

b2 = tk.Button(root, text="Verde", command=verde)
b2.place(x=170, y=80, width=80, height=40)

root.mainloop()

"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk
from pathlib import Path

# Exemplu de cale absoluta generata din folderul proiectului.
# Pe Windows puteti inlocui cu ceva de forma:
# cale = Path(r"C:\Users\Paul\Desktop\text.txt")
cale = DATA_DIR / "text.txt"

def citeste_fisier():
    with open(cale, "r", encoding="utf-8") as f:
        text = f.read()

    label.config(text=text[:200])

root = tk.Tk()
root.geometry("550x250")
root.title("Citire fisier prin cale absoluta")

btn = tk.Button(root, text="Citeste", command=citeste_fisier)
btn.pack(pady=10)

label = tk.Label(root, text="", wraplength=500, justify="left")
label.pack(pady=10)

root.mainloop()

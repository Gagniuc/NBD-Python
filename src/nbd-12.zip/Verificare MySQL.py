import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="nbd_bank"
)

cursor = conn.cursor()

query = """
SELECT id, client, amount, country, hour
FROM transactions
WHERE amount > 5000
   OR hour < 5
   OR country IN ('RU', 'NG', 'KP')
"""

cursor.execute(query)

rows = cursor.fetchall()

print("Tranzacții suspecte:")

for row in rows:
    print(row)

cursor.close()
conn.close()
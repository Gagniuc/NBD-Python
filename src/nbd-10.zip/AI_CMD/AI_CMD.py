import requests
import json
import subprocess

text_client = input("Ce vrei sa afli? ")

prompt = """
Raspunde numai cu JSON.

{
  "comanda":""
}

Comenzi permise:
hostname
ipconfig
getmac
tasklist

Cerere:
""" + text_client

r = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "llama3.2",
        "prompt": prompt,
        "format": "json",
        "stream": False
    }
)

date = json.loads(r.json()["response"])

comanda = date["comanda"]

print("Comanda aleasa:", comanda)

rezultat = subprocess.check_output(
    comanda,
    shell=True,
    text=True,
    encoding="utf-8",
    errors="ignore"
)

print(rezultat)
from flask import Flask

app = Flask(__name__)

@app.route("/calculeaza/<sir1>/<sir2>")
def calculeaza(sir1, sir2):

    lista1 = sir1.split(",")
    lista2 = sir2.split(",")

    numere1 = [float(x) for x in lista1]
    numere2 = [float(x) for x in lista2]

    suma1 = sum(numere1)
    suma2 = sum(numere2)

    return "Suma sir 1 = " + str(suma1) + "<br>Suma sir 2 = " + str(suma2)

app.run(debug=True)


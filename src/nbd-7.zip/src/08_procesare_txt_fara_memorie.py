"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

fisier = DATA_DIR / "date_mari.txt"

total = 0
numar_linii = 0

with open(fisier, "r", encoding="utf-8") as f:
    for linie in f:
        total += int(linie)
        numar_linii += 1

print("Numar linii:", numar_linii)
print("Total:", total)

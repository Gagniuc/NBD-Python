import smtplib
from email.mime.text import MIMEText

gmail = "gagniucp@gmail.com"
parola = "otjx fwgg djnn waot"

with open(r"C:\Users\Paul\Desktop\pagina.html", "r", encoding="utf-8") as f:
    html = f.read()

mesaj = MIMEText(html, "html")
mesaj["Subject"] = "Test Python HTML"
mesaj["From"] = gmail
mesaj["To"] = "gagniucp@gmail.com"

server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
server.login(gmail, parola)
server.send_message(mesaj)
server.quit()

print("Email trimis")

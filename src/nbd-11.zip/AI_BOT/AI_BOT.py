import os
import requests

folder_documente = r"C:\Users\Paul\Desktop\documente_ai"
model = "llama3.2"

fragmente = []

def antrenare():
    global fragmente
    fragmente = []

    for nume_fisier in os.listdir(folder_documente):
        if nume_fisier.endswith(".txt"):
            cale = os.path.join(folder_documente, nume_fisier)

            with open(cale, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()

            bucati = text.split("\n\n")

            for bucata in bucati:
                bucata = bucata.strip()
                if bucata != "":
                    fragmente.append({
                        "fisier": nume_fisier,
                        "text": bucata
                    })

    print("Documente incarcate:", len(fragmente), "fragmente")

def cauta_context(intrebare):
    cuvinte = intrebare.lower().split()
    rezultate = []

    for fragment in fragmente:
        scor = 0
        text_mic = fragment["text"].lower()

        for cuvant in cuvinte:
            if cuvant in text_mic:
                scor = scor + 1

        if scor > 0:
            rezultate.append((scor, fragment))

    rezultate.sort(reverse=True, key=lambda x: x[0])

    context = ""

    for scor, fragment in rezultate[:5]:
        context = context + "\n[SURSA: " + fragment["fisier"] + "]\n"
        context = context + fragment["text"] + "\n"

    return context

def intreaba_ai(intrebare):
    context = cauta_context(intrebare)

    prompt = """
Raspunde folosind doar contextul de mai jos.
Daca informatia nu exista in context, spune: Nu gasesc informatia in documente.

Context:
""" + context + """

Intrebare:
""" + intrebare

    r = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": model,
            "prompt": prompt,
            "stream": False
        }
    )

    return r.json()["response"]

antrenare()

while True:
    intrebare = input("\nIntrebare: ")

    if intrebare.lower() == "exit":
        break

    raspuns = intreaba_ai(intrebare)

    print("\nRaspuns AI:")
    print(raspuns)
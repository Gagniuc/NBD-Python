import smtplib
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

gmail = "gagniucp@gmail.com"
parola = "otjx fwgg djnn waot"

mesaj = MIMEMultipart("related")

mesaj["Subject"] = "Test HTML cu imagine"
mesaj["From"] = gmail
mesaj["To"] = "gagniucp@gmail.com"

html = """
<html>
<body>

<h1>New Business Dimensions</h1>

<p>Mesaj trimis automat din Python.</p>

<p>
<a href="https://nbd.ro/en/">
Viziteaza site-ul NBD
</a>
</p>

<img src="cid:logo_nbd">

</body>
</html>
"""

mesaj.attach(MIMEText(html, "html"))

with open(r"C:\Users\Paul\Desktop\logo.gif", "rb") as f:

    img = MIMEImage(f.read())

    img.add_header("Content-ID", "<logo_nbd>")

    mesaj.attach(img)

server = smtplib.SMTP_SSL("smtp.gmail.com", 465)

server.login(gmail, parola)

server.send_message(mesaj)

server.quit()

print("Email trimis")
from cryptography.fernet import Fernet
import base64
import hashlib

def make_key(password):
    return base64.urlsafe_b64encode(
        hashlib.sha256(password.encode()).digest()
    )

def encrypt(text, password):
    f = Fernet(make_key(password))
    return f.encrypt(str(text).encode()).decode()

def decrypt(text, password):
    f = Fernet(make_key(password))
    return f.decrypt(text.encode()).decode()

secret = encrypt("15000", "parola123")
print(secret)

normal = decrypt(secret, "parola123")
print(normal)



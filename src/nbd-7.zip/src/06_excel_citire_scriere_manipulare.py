"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import pandas as pd

# Creare tabel si salvare Excel
df = pd.DataFrame({
    "nume": ["Ana", "Ion"],
    "nota": [9, 7]
})

fisier_generat = OUTPUT_DIR / "note_generate.xlsx"
df.to_excel(fisier_generat, index=False)

# Citire Excel existent
df2 = pd.read_excel(DATA_DIR / "note.xlsx")

# Manipulare: crestem nota cu 1, dar nu peste 10
df2["nota"] = (df2["nota"] + 1).clip(upper=10)

print(df2)

fisier_modificat = OUTPUT_DIR / "note_modificat.xlsx"
df2.to_excel(fisier_modificat, index=False)

print("Fisier salvat:", fisier_modificat)

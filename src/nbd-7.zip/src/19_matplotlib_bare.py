"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import matplotlib.pyplot as plt

departamente = ["IT", "HR", "Financiar", "Sales"]
numar_angajati = [4, 2, 2, 1]

plt.bar(departamente, numar_angajati)
plt.xlabel("Departament")
plt.ylabel("Numar angajati")
plt.title("Angajati pe departamente")
plt.show()

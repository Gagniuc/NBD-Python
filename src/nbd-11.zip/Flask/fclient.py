import requests

date = {
    "nume": "Paul",
    "text": "Salut din Python"
}

r = requests.post("http://localhost:5000/mesaj", data=date)

print(r.text)
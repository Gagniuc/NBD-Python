"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import json

student = {
    "nume": "Popescu",
    "varsta": 21,
    "note": [9, 10, 8]
}

fisier = OUTPUT_DIR / "student_generat.json"

with open(fisier, "w", encoding="utf-8") as f:
    json.dump(student, f, ensure_ascii=False, indent=4)

print("Fisier JSON scris:", fisier)

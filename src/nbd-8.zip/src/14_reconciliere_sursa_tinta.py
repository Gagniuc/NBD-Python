\
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

sursa = pd.read_csv(DATA / "sursa.csv")
tinta = pd.read_csv(DATA / "tinta.csv")

comparatie = sursa.merge(
    tinta,
    on="cont",
    suffixes=("_sursa", "_tinta")
)

comparatie["diferenta"] = (
    comparatie["sold_sursa"] - comparatie["sold_tinta"]
)

erori = comparatie[
    comparatie["diferenta"] != 0
]

print(erori)

erori.to_excel(OUT / "raport_diferente.xlsx", index=False)
print("Raport generat:", OUT / "raport_diferente.xlsx")

import imaplib
import email
import requests
from email.header import decode_header

gmail = "gagniucp@gmail.com"
parola = "otjxfwggdjnnwaot"

server = imaplib.IMAP4_SSL("imap.gmail.com")
server.login(gmail, parola)
server.select("INBOX")

status, mesaje = server.search(None, "ALL")
iduri = mesaje[0].split()

id_email = iduri[-1]

status, date = server.fetch(id_email, "(RFC822)")
mesaj = email.message_from_bytes(date[0][1])

subiect = mesaj["Subject"]

if subiect:
    subiect = decode_header(subiect)[0][0]

    if isinstance(subiect, bytes):
        subiect = subiect.decode(
            "utf-8",
            errors="ignore"
        )

expeditor = mesaj["From"]

continut = ""

if mesaj.is_multipart():

    for parte in mesaj.walk():

        tip = parte.get_content_type()

        if tip == "text/plain":

            continut = parte.get_payload(
                decode=True
            ).decode(
                errors="ignore"
            )

            break

        if tip == "text/html" and continut == "":

            continut = parte.get_payload(
                decode=True
            ).decode(
                errors="ignore"
            )

else:

    continut = mesaj.get_payload(
        decode=True
    ).decode(
        errors="ignore"
    )

prompt = f"""
Clasifica emailul.

Alege EXACT o categorie:

- Reclamație
- Fraudă
- Suport tehnic
- Carduri
- Credite
- Marketing
- Spam
- Newsletter
- Altele

Prioritate:
- Scazuta
- Medie
- Ridicata
- Urgenta

Raspunde EXACT asa:

Categorie=<categorie>
Prioritate=<prioritate>
Rezumat=<o propozitie>

Subiect:
{subiect}

Mesaj:
{continut[:5000]}
"""

r = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "llama3.2",
        "prompt": prompt,
        "stream": False
    },
    timeout=120
)

print()
print("========================================")
print("De la:", expeditor)
print("Subiect:", subiect)
print("========================================")
print()
print(r.json()["response"])
print()

server.logout()
\
import tkinter as tk
from tkinter import messagebox
from datetime import datetime

evenimente = []

def adauga_eveniment():
    ora = entry_ora.get().strip()
    descriere = entry_descriere.get().strip()

    if not ora or not descriere:
        messagebox.showerror("Eroare", "Completati ora si descrierea.")
        return

    evenimente.append((ora, descriere))
    lista.insert(tk.END, f"{ora} - {descriere}")

def verifica_evenimente():
    acum = datetime.now().strftime("%H:%M")

    for ora, descriere in evenimente:
        if ora == acum:
            messagebox.showinfo("Notificare", descriere)

    root.after(60000, verifica_evenimente)

root = tk.Tk()
root.title("Event Notifier simplificat")
root.geometry("420x300")

tk.Label(root, text="Ora (HH:MM)").pack()
entry_ora = tk.Entry(root)
entry_ora.pack()

tk.Label(root, text="Descriere").pack()
entry_descriere = tk.Entry(root, width=50)
entry_descriere.pack()

tk.Button(root, text="Adauga eveniment", command=adauga_eveniment).pack(pady=10)

lista = tk.Listbox(root, width=55)
lista.pack(pady=10)

verifica_evenimente()

root.mainloop()

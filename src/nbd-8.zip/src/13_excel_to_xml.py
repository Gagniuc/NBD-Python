\
from pathlib import Path
import pandas as pd
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

df = pd.read_excel(DATA / "date.xlsx", sheet_name="Raport")

raport = ET.Element("raport")

for index, row in df.iterrows():
    item = ET.SubElement(raport, "item")
    item.set("name", str(row["indicator"]))
    item.text = str(row["valoare"])

tree = ET.ElementTree(raport)

cale_iesire = OUT / "fisier_generat.xml"
tree.write(cale_iesire, encoding="utf-8", xml_declaration=True)

print("Fisier XML generat:", cale_iesire)

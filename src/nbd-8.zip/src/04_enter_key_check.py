\
import tkinter as tk
from tkinter import messagebox

def verifica():
    text = entry.get()
    if text.strip():
        label.config(text=f"Text introdus: {text}")
    else:
        messagebox.showerror("Eroare", "Campul este gol.")

root = tk.Tk()
root.title("Check cu Enter")
root.geometry("320x150")

entry = tk.Entry(root)
entry.pack(pady=10)

button = tk.Button(root, text="Check", command=verifica)
button.pack()

label = tk.Label(root, text="")
label.pack(pady=10)

root.bind("<Return>", lambda event: verifica())

root.mainloop()

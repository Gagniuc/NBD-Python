import base64

cale_imagine = r"C:\Users\Paul\Desktop\logo.png"

with open(cale_imagine, "rb") as f:
    baza64 = base64.b64encode(f.read()).decode("utf-8")

print(baza64)

with open(r"C:\Users\Paul\Desktop\imagine_base64.txt", "w", encoding="utf-8") as f:
    f.write(baza64)

print("Salvat in imagine_base64.txt")

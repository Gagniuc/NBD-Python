"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import matplotlib.pyplot as plt

varste = [24, 29, 31, 34, 38, 41, 45, 52]
venituri = [3200, 4100, 4500, 5500, 6200, 6700, 7100, 8000]

plt.scatter(varste, venituri)
plt.xlabel("Varsta")
plt.ylabel("Venit")
plt.title("Relatia dintre varsta si venit")
plt.show()

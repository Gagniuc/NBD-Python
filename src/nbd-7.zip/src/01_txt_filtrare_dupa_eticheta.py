"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

fisier = DATA_DIR / "log.txt"

contor = {
    "INFO": 0,
    "WARNING": 0,
    "ERROR": 0
}

print("Linii cu ERROR:")
with open(fisier, "r", encoding="utf-8") as f:
    for line in f:
        linie = line.strip()

        for eticheta in contor:
            if linie.startswith(eticheta):
                contor[eticheta] += 1

        if linie.startswith("ERROR"):
            print(linie)

print()
print("Numarare etichete:")
print(contor)

"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk
from tkinter.scrolledtext import ScrolledText

def incarca():
    fisier = DATA_DIR / "text.txt"

    with open(fisier, "r", encoding="utf-8") as f:
        continut = f.read()

    textbox.delete("1.0", tk.END)
    textbox.insert(tk.END, continut)

root = tk.Tk()
root.geometry("600x350")
root.title("Fisier in TextBox cu scrollbar")

btn = tk.Button(root, text="Incarca fisier", command=incarca)
btn.pack(pady=10)

textbox = ScrolledText(root, width=70, height=15)
textbox.pack(padx=10, pady=10)

root.mainloop()

\
from pathlib import Path
import pandas as pd

DATA = Path(__file__).resolve().parents[1] / "date_input"
fisier = DATA / "date.xlsx"

toate_foile = pd.read_excel(fisier, sheet_name=None)

for nume_foaie, tabel in toate_foile.items():
    print("Foaie:", nume_foaie)
    print(tabel.head())
    print()

"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk
from tkinter import messagebox

def verifica():
    text = entry.get()

    try:
        valoare = float(text.replace(",", "."))
        label_rezultat.config(text=f"Valoare valida: {valoare}")
    except ValueError:
        messagebox.showerror("Eroare", "Introduceti un numar valid.")

root = tk.Tk()
root.title("Validare input")
root.geometry("300x150")

entry = tk.Entry(root)
entry.pack(pady=10)

button = tk.Button(root, text="Check", command=verifica)
button.pack()

label_rezultat = tk.Label(root, text="")
label_rezultat.pack(pady=10)

root.bind("<Return>", lambda event: verifica())

root.mainloop()

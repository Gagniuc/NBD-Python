"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk

def calc():
    a = int(e1.get())
    b = int(e2.get())
    rezultat.config(text=str(a + b))

root = tk.Tk()
root.geometry("300x200")
root.title("Calculator")

e1 = tk.Entry(root)
e1.place(x=50, y=30, width=80)

e2 = tk.Entry(root)
e2.place(x=170, y=30, width=80)

btn = tk.Button(root, text="+", command=calc)
btn.place(x=120, y=70, width=60, height=30)

rezultat = tk.Label(root, text="")
rezultat.place(x=100, y=120, width=100, height=30)

root.mainloop()

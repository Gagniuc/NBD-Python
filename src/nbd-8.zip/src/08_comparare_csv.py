\
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

df1 = pd.read_csv(DATA / "fisier1.csv")
df2 = pd.read_csv(DATA / "fisier2.csv")

diferente = df1.merge(df2, how="outer", indicator=True)
diferente = diferente[diferente["_merge"] != "both"]

print(diferente)

diferente.to_csv(OUT / "diferente.csv", index=False)
print("Fisier salvat:", OUT / "diferente.csv")

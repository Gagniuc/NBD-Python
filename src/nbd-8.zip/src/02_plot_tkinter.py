\
import tkinter as tk
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

x = [1, 2, 3, 4, 5]
y = [10, 14, 13, 18, 20]

def deseneaza_plot():
    ax.clear()
    ax.plot(x, y)
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_title("Line plot")
    canvas.draw()

root = tk.Tk()
root.title("Plot in aceeasi fereastra")
root.geometry("700x500")

buton = tk.Button(root, text="Afiseaza plot", command=deseneaza_plot)
buton.pack(pady=10)

fig = Figure(figsize=(6, 4), dpi=100)
ax = fig.add_subplot(111)

canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

root.mainloop()

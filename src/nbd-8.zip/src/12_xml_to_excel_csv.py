\
from pathlib import Path
import os
import xml.etree.ElementTree as ET
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

cale_fisier = DATA / "raport.xml"

if not os.path.exists(cale_fisier):
    print("Eroare: fisierul nu exista:")
    print(cale_fisier)
    exit()

tree = ET.parse(cale_fisier)
root = tree.getroot()

date = []

for element in root.findall("item"):
    date.append({
        "indicator": element.attrib.get("name"),
        "valoare": element.text
    })

df = pd.DataFrame(date)

print(df)

df.to_excel(OUT / "raport_excel.xlsx", index=False)
df.to_csv(OUT / "raport_csv.csv", index=False)

print("Export terminat:", OUT)

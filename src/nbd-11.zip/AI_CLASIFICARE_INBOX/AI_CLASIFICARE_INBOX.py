import imaplib
import email
import requests
from email.header import decode_header

gmail = "gagniucp@gmail.com"
parola = "otjxfwggdjnnwaot"

server = imaplib.IMAP4_SSL("imap.gmail.com")
server.login(gmail, parola)
server.select("INBOX")

status, mesaje = server.search(None, "ALL")
iduri = mesaje[0].split()
ultimele = iduri[-5:]

for id_email in ultimele:
    status, date = server.fetch(id_email, "(BODY.PEEK[HEADER])")
    mesaj_header = email.message_from_bytes(date[0][1])

    subiect = mesaj_header["Subject"]
    if subiect:
        subiect = decode_header(subiect)[0][0]
        if isinstance(subiect, bytes):
            subiect = subiect.decode("utf-8", errors="ignore")

    expeditor = mesaj_header["From"]

    prompt = f"""
    Esti un clasificator de emailuri.

    Categorii permise:
    - Reclamație
    - Fraudă
    - Suport tehnic
    - Carduri
    - Credite
    - Marketing
    - Spam
    - Newsletter
    - Altele

    Prioritati permise:
    - Scazuta
    - Medie
    - Ridicata
    - Urgenta

    Raspunde EXACT asa:

    Categorie=<categorie>
    Prioritate=<prioritate>

    Subiect:
    {subiect}

    Expeditor:
    {expeditor}
    """

    print("Trimit la Llama:", subiect)

    try:
        r = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "llama3.2",
                "prompt": prompt,
                "stream": False
            },
            timeout=30
        )

        raspuns_ai = r.json()["response"].strip()

    except requests.exceptions.Timeout:
        raspuns_ai = "Llama nu a raspuns in 30 secunde."

    print("========================================")
    print("De la:", expeditor)
    print("Subiect:", subiect)
    print("AI:", raspuns_ai)
    print("========================================")

server.logout()
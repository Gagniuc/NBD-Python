# Fișiere sursă

- `log.txt` - fișier de log cu INFO, WARNING și ERROR.
- `angajati.csv` - angajați pentru filtrare și calcule.
- `student.json` - structură JSON pentru citire și procesare.
- `note.xlsx` - fișier Excel pentru citire/scriere.
- `date_mari.txt` - fișier text cu valori numerice.
- `date_mari.csv` - CSV pentru procesare în bucăți.
- `text.txt` - fișier text pentru exemple GUI.
- `vanzari.csv` - vânzări lunare pentru plotare.
- `clienti.csv` - date cu lipsuri și duplicate.
- `clienti.xlsx` - variantă Excel pentru datele de clienți.

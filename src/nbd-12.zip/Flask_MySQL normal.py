from flask import Flask
import mysql.connector

from cryptography.fernet import Fernet
import base64
import hashlib

def make_key(password):
    return base64.urlsafe_b64encode(
        hashlib.sha256(password.encode()).digest()
    )

def encrypt(text, password):
    f = Fernet(make_key(password))
    return f.encrypt(str(text).encode()).decode()

def decrypt(text, password):
    f = Fernet(make_key(password))
    return f.decrypt(text.encode()).decode()


app = Flask(__name__)

def db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="nbd_bank"
    )

@app.route("/")
def home():
    return "NBD Flask + MySQL"


@app.route("/setup")
def setup():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password=""
    )

    cursor = conn.cursor()

    cursor.execute("CREATE DATABASE IF NOT EXISTS nbd_bank")
    cursor.execute("USE nbd_bank")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        client VARCHAR(50),
        amount FLOAT
    )
    """)

    conn.commit()
    conn.close()

    return "Database and table created"



@app.route("/all")
def all_data():
    conn = db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM transactions")
    rows = cursor.fetchall()

    conn.close()

    return str(rows)


@app.route("/insert/<client>/<amount>")
def insert(client, amount):
    conn = db()
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO transactions(client, amount) VALUES(%s, %s)",
        (client, amount)
    )

    conn.commit()
    conn.close()

    return "Inserted"


@app.route("/search/<client>")
def search(client):
    conn = db()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM transactions WHERE client=%s",
        (client,)
    )

    rows = cursor.fetchall()
    conn.close()

    return str(rows)


@app.route("/delete/<id>")
def delete(id):
    conn = db()
    cursor = conn.cursor()

    cursor.execute(
        "DELETE FROM transactions WHERE id=%s",
        (id,)
    )

    conn.commit()
    conn.close()

    return "Deleted"


@app.route("/update/<id>/<amount>")
def update(id, amount):
    conn = db()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE transactions SET amount=%s WHERE id=%s",
        (amount, id)
    )

    conn.commit()
    conn.close()

    return "Updated"



@app.route("/clear")
def clear():
    conn = db()
    cursor = conn.cursor()

    cursor.execute("TRUNCATE TABLE transactions")

    conn.commit()
    conn.close()

    return "Table cleared"


@app.route("/insert/<client>/<amount>/<country>/<hour>")
def insert_complet(client, amount, country, hour):
    conn = db()
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO transactions(client, amount, country, hour) VALUES(%s, %s, %s, %s)",
        (client, amount, country, hour)
    )

    conn.commit()
    conn.close()

    return "Inserted"



@app.route("/seed")
def seed():
    conn = db()
    cursor = conn.cursor()

    data = [
        ("C1", 120, "RO", 14),
        ("C2", 15000, "RU", 2),
        ("C3", 80, "RO", 11),
        ("C4", 9700, "NG", 3),
        ("C5", 300, "FR", 21)
    ]

    cursor.executemany(
        "INSERT INTO transactions(client, amount, country, hour) VALUES(%s,%s,%s,%s)",
        data
    )

    conn.commit()
    conn.close()

    return "Test data inserted"



@app.route("/suspect")
def suspect():
    conn = db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM transactions
        WHERE amount > 5000 OR hour < 5 OR country IN ('RU', 'NG', 'KP')
    """)

    rows = cursor.fetchall()
    conn.close()

    return str(rows)



@app.route("/stats")
def stats():
    conn = db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            COUNT(*) AS total_tranzactii,
            SUM(amount) AS suma_totala,
            AVG(amount) AS media
        FROM transactions
    """)

    row = cursor.fetchone()
    conn.close()

    return str(row)


@app.route("/client_total/<client>")
def client_total(client):
    conn = db()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT client, SUM(amount) FROM transactions WHERE client=%s GROUP BY client",
        (client,)
    )

    row = cursor.fetchone()
    conn.close()

    return str(row)



@app.route("/setup_secure")
def setup_secure():
    conn = db()
    cursor = conn.cursor()

    cursor.execute("DROP TABLE IF EXISTS secure_transactions")

    cursor.execute("""
    CREATE TABLE secure_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        client VARCHAR(50),
        amount TEXT,
        country TEXT,
        hour TEXT
    )
    """)

    conn.commit()
    conn.close()

    return "Secure table created"




@app.route("/insert_secure/<client>/<amount>/<country>/<hour>/<password>")
def insert_secure(client, amount, country, hour, password):
    conn = db()
    cursor = conn.cursor()

    encrypted_amount = encrypt(amount, password)
    encrypted_country = encrypt(country, password)
    encrypted_hour = encrypt(hour, password)

    cursor.execute(
        "INSERT INTO secure_transactions(client, amount, country, hour) VALUES(%s, %s, %s, %s)",
        (client, encrypted_amount, encrypted_country, encrypted_hour)
    )

    conn.commit()
    conn.close()

    return "Encrypted insert done"



@app.route("/secure_raw")
def secure_raw():
    conn = db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM secure_transactions")
    rows = cursor.fetchall()

    conn.close()

    return str(rows)




@app.route("/show_secure/<password>")
def show_secure(password):
    conn = db()
    cursor = conn.cursor()

    cursor.execute("SELECT client, amount, country, hour FROM secure_transactions")
    rows = cursor.fetchall()

    result = ""

    for client, amount, country, hour in rows:
        amount_dec = decrypt(amount, password)
        country_dec = decrypt(country, password)
        hour_dec = decrypt(hour, password)

        result += f"{client} | {amount_dec} | {country_dec} | {hour_dec}<br>"

    conn.close()

    return result




@app.route("/search_like/<name>")
def search_like(name):
    conn = db()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM transactions WHERE client LIKE %s",
        ("%" + name + "%",)
    )

    rows = cursor.fetchall()
    conn.close()

    return str(rows)


app.run(debug=True)


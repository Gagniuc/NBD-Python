import requests
import json
import subprocess

comanda = input("Comanda: ")

prompt = """
Raspunde EXCLUSIV cu JSON valid.
Nu scrie explicatii.
Nu scrie markdown.
Nu scrie text inainte sau dupa JSON.

Ai voie sa folosesti DOAR aceasta actiune:
popup

Ai voie sa folosesti DOAR aceste culori:
red
green
blue
yellow
orange
purple
random

Daca utilizatorul scrie rosie, foloseste red.
Daca utilizatorul scrie verde, foloseste green.
Daca utilizatorul scrie albastra, foloseste blue.
Daca utilizatorul cere culori diferite, foloseste random.

Format obligatoriu:
{
  "actiune": "popup",
  "numar": 3,
  "culoare": "red"
}

Comanda utilizator:
""" + comanda

r = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "llama3.2",
        "prompt": prompt,
        "format": "json",
        "stream": False
    }
)

text = r.json()["response"].strip()

print("\nJSON primit:")
print(text)

date = json.loads(text)

actiune = date.get("actiune", "")
numar = int(date.get("numar", 1))
culoare = date.get("culoare", "red")

actiune = actiune.lower()
culoare = culoare.lower()

if actiune != "popup":
    actiune = "popup"

if culoare == "rosie" or culoare == "roșie":
    culoare = "red"

if culoare == "verde":
    culoare = "green"

if culoare == "albastra" or culoare == "albastră":
    culoare = "blue"

if culoare == "galbena" or culoare == "galbenă":
    culoare = "yellow"

if culoare == "portocalie":
    culoare = "orange"

if culoare == "mov":
    culoare = "purple"

culori = ["red", "green", "blue", "yellow", "orange", "purple"]

for i in range(numar):
    culoare_curenta = culoare

    if culoare == "random":
        culoare_curenta = culori[i % len(culori)]

    subprocess.Popen([
        "python",
        r"C:\xampp\htdocs\executie\fereastra.py",
        "ALERTA AI",
        culoare_curenta,
        str(i + 1),
        "LLAMA"
    ])

    #subprocess.Popen([
    #r"C:\xampp\htdocs\executie\fereastra.exe",
    #"ALERTA AI",
    #culoare_curenta,
    #str(i + 1),
    #"LLAMA"
    #])

print("Executat:", numar, "popup-uri")
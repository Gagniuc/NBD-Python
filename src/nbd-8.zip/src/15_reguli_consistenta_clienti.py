\
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

df = pd.read_excel(DATA / "clienti.xlsx")

erori = []

for index, row in df.iterrows():

    if row["venit"] <= 0:
        erori.append([
            row["client"],
            "Venitul trebuie sa fie pozitiv"
        ])

    if row["datorie"] < 0:
        erori.append([
            row["client"],
            "Datoria nu poate fi negativa"
        ])

    if row["varsta"] < 18 or row["varsta"] > 100:
        erori.append([
            row["client"],
            "Varsta invalida"
        ])

raport_erori = pd.DataFrame(
    erori,
    columns=["client", "eroare"]
)

print(raport_erori)

raport_erori.to_excel(
    OUT / "erori_validare.xlsx",
    index=False
)

print("Validare terminata.")

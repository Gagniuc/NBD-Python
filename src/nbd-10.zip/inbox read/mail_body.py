import imaplib
import email
from email.header import decode_header

gmail = "gagniucp@gmail.com"
parola = "otjxfwggdjnnwaot"

server = imaplib.IMAP4_SSL("imap.gmail.com")
server.login(gmail, parola)
server.select("INBOX")

status, mesaje = server.search(None, "ALL")
iduri = mesaje[0].split()
ultimele = iduri[-5:]

for id_email in ultimele:
    status, date = server.fetch(id_email, "(RFC822)")
    mesaj = email.message_from_bytes(date[0][1])

    subiect = mesaj["Subject"]
    if subiect:
        subiect = decode_header(subiect)[0][0]
        if isinstance(subiect, bytes):
            subiect = subiect.decode("utf-8", errors="ignore")

    expeditor = mesaj["From"]
    continut = ""

    if mesaj.is_multipart():
        for parte in mesaj.walk():
            tip = parte.get_content_type()
            if tip == "text/plain":
                continut = parte.get_payload(decode=True).decode(errors="ignore")
                break
    else:
        continut = mesaj.get_payload(decode=True).decode(errors="ignore")

    print("De la:", expeditor)
    print("Subiect:", subiect)
    print("Mesaj:")
    print(continut[:1000])
    print("-" * 40)

server.logout()
"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import matplotlib.pyplot as plt

salarii = [5500, 4300, 6200, 7000, 4800, 5100, 8000, 6100, 5900, 4700]

plt.hist(salarii, bins=5)
plt.xlabel("Salariu")
plt.ylabel("Frecventa")
plt.title("Distributia salariilor")
plt.show()

\
import tkinter as tk
from tkinter import messagebox

def smooth(lista, fereastra=3):
    rezultat = []
    for i in range(len(lista)):
        start = max(0, i - fereastra + 1)
        valori = lista[start:i+1]
        rezultat.append(sum(valori) / len(valori))
    return rezultat

def calculeaza():
    text = entry.get()
    try:
        valori = [float(x.strip().replace(",", ".")) for x in text.split(";")]
        valori_smooth = smooth(valori, 3)
        label.config(text=str(valori_smooth))
    except ValueError:
        messagebox.showerror("Eroare", "Introduceti valori separate prin ;")

root = tk.Tk()
root.geometry("500x200")
root.title("Smooth numeric")

entry = tk.Entry(root, width=60)
entry.pack(pady=10)
entry.insert(0, "10; 12; 11; 20; 19; 21")

button = tk.Button(root, text="Calculeaza smooth", command=calculeaza)
button.pack()

label = tk.Label(root, text="")
label.pack(pady=10)

root.mainloop()

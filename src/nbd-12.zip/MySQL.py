import mysql.connector

# 1. Conectare la MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password=""
)

cursor = conn.cursor()

# 2. Creare bază de date
cursor.execute("CREATE DATABASE IF NOT EXISTS nbd_bank")

# 3. Selectare bază de date
cursor.execute("USE nbd_bank")

# 4. Creare tabelă
cursor.execute("""
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client VARCHAR(50),
    amount FLOAT,
    country VARCHAR(10),
    hour INT
)
""")

# 5. Date de test
data = [
    ("C1", 120, "RO", 14),
    ("C2", 15000, "RU", 2),
    ("C3", 80, "RO", 11),
    ("C4", 9700, "NG", 3),
    ("C5", 300, "FR", 21)
]

# 6. Inserare date
cursor.executemany("""
INSERT INTO transactions (client, amount, country, hour)
VALUES (%s, %s, %s, %s)
""", data)

conn.commit()

# 7. Citire date din tabelă
cursor.execute("SELECT * FROM transactions")

rows = cursor.fetchall()

print("Tranzacții salvate în MySQL:")

for row in rows:
    print(row)

# 8. Închidere conexiune
cursor.close()
conn.close()
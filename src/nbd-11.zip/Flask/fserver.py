from flask import Flask, request

app = Flask(__name__)

@app.route("/mesaj", methods=["POST"])
def mesaj():
    nume = request.form.get("nume")
    text = request.form.get("text")
    return "Am primit de la " + nume + ": " + text

app.run(debug=True)

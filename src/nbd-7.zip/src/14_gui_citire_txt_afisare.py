"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import tkinter as tk

def citeste_fisier():
    fisier = DATA_DIR / "text.txt"

    with open(fisier, "r", encoding="utf-8") as f:
        text = f.read()

    # Afisam doar primele 100 de caractere
    label.config(text=text[:100])

root = tk.Tk()
root.geometry("500x250")
root.title("Citire fisier text")

btn = tk.Button(root, text="Citeste fisier", command=citeste_fisier)
btn.pack(pady=10)

label = tk.Label(root, text="", wraplength=450, justify="left")
label.pack(pady=10)

root.mainloop()

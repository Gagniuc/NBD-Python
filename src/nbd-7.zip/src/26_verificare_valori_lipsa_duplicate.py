"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import pandas as pd

df = pd.read_csv(DATA_DIR / "clienti.csv")

print("Valori lipsa:")
print(df.isna().sum())

print()
print("Duplicate:")
print(df.duplicated().sum())

df_curat = df.dropna()
df_curat = df_curat.drop_duplicates()

print()
print("Dimensiune initiala:", df.shape)
print("Dimensiune dupa curatare:", df_curat.shape)

fisier_output = OUTPUT_DIR / "clienti_curat.csv"
df_curat.to_csv(fisier_output, index=False)

print("Fisier curat salvat:", fisier_output)

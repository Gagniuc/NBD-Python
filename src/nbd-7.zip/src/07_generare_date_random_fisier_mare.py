"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import random
import csv

fisier_txt = OUTPUT_DIR / "date_mari_generate.txt"
fisier_csv = OUTPUT_DIR / "date_mari_generate.csv"

with open(fisier_txt, "w", encoding="utf-8") as f:
    for i in range(100000):
        numar = random.randint(1, 1000)
        f.write(str(numar) + "\n")

with open(fisier_csv, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["id", "valoare"])
    for i in range(100000):
        writer.writerow([i + 1, random.randint(1, 1000)])

print("Fisiere generate:")
print(fisier_txt)
print(fisier_csv)

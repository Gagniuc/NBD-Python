import pytesseract
from PIL import Image, ImageEnhance
import requests
import json

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

cale = r"C:\Users\Paul\Desktop\factura.png"

img = Image.open(cale)
img = img.convert("L")
img = img.resize((img.width * 3, img.height * 3))
img = ImageEnhance.Contrast(img).enhance(2)

text = pytesseract.image_to_string(img, lang="ron+eng")

print("TEXT OCR:")
print(text)
print("-" * 50)

prompt = """
Extrage datele din urmatorul text OCR al unei facturi.

Raspunde numai cu JSON valid.
Nu scrie explicatii.
Nu scrie markdown.

Campuri:
vanzator, cumparator, numar_factura, data_emitere, data_scadenta, moneda, total_net, total_tva, total_plata, produse.

La produse foloseste lista cu:
denumire, cantitate, pret_unitar, cota_tva, valoare_neta.

Text OCR:
""" + text

r = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "llama3.2",
        "prompt": prompt,
        "format": "json",
        "stream": False
    }
)

raspuns = r.json()["response"].strip()

print("JSON EXTRAS:")
print(raspuns)

date = json.loads(raspuns)

with open(r"C:\Users\Paul\Desktop\factura_extrasa.json", "w", encoding="utf-8") as f:
    json.dump(date, f, indent=4, ensure_ascii=False)

print("Salvat pe Desktop: factura_extrasa.json")
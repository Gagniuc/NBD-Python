\
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "produse.csv")

raport = df.groupby(["regiune", "tip_client"])["produs"].count()

print(raport)

raport.to_excel(OUT / "raport_statistic.xlsx")
print("Fisier salvat:", OUT / "raport_statistic.xlsx")

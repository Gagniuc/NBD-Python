\
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "date_input"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "clienti.csv")

print("Valori lipsa:")
print(df.isna().sum())

print("Duplicate:")
print(df.duplicated().sum())

df_curat = df.dropna()
df_curat = df_curat.drop_duplicates()

print("Dimensiune initiala:", df.shape)
print("Dimensiune dupa curatare:", df_curat.shape)

df_curat.to_csv(OUT / "clienti_curat.csv", index=False)
print("Fisier salvat:", OUT / "clienti_curat.csv")

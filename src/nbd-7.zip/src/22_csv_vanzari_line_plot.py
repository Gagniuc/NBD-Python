"""
Exemplu pentru cursul NBD - Python aplicat.
Rulare: python nume_script.py
Fisierele sursa sunt in folderul ../data.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(DATA_DIR / "vanzari.csv")

plt.plot(df["luna"], df["vanzari"], marker="o")
plt.xlabel("Luna")
plt.ylabel("Vanzari")
plt.title("Vanzari din CSV")
plt.show()

\
from pathlib import Path
import pandas as pd

DATA = Path(__file__).resolve().parents[1] / "date_input"
fisier = DATA / "date_mari.csv"

total = 0

for bucata in pd.read_csv(fisier, chunksize=1000):
    total += bucata["valoare"].sum()

print("Total:", total)

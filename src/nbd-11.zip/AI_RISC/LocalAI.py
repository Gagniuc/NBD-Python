import requests
import json

text_client = input("Mesaj client: ")

prompt = """
Raspunde numai cu JSON valid.
Nu scrie explicatii.
Nu scrie markdown.
Nu scrie text inainte sau dupa JSON.
Foloseste exact aceste campuri:
departament, prioritate, risc, rezumat, actiune_recomandata, raspuns_client.
Valori posibile pentru prioritate: normala, mare, critica.
Mesaj client:
""" + text_client

r = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "llama3.2",
        "prompt": prompt,
        "format": "json",
        "stream": False
    }
)

raspuns_ollama = r.json()
text = raspuns_ollama["response"].strip()

print("JSON primit:")
print(text)

date = json.loads(text)

print("Departament:", date["departament"])
print("Prioritate:", date["prioritate"])
print("Risc:", date["risc"])
print("Rezumat:", date["rezumat"])
print("Actiune recomandata:", date["actiune_recomandata"])
print("Raspuns propus:", date["raspuns_client"])

if date["prioritate"].lower() == "critica":
    print("ALERTA: cazul trebuie preluat imediat!")